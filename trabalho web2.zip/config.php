<?php
// config.php - ajuste suas credenciais aqui
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'web_system',
    'db_user' => 'root',
    'db_pass' => '',
    'base_url' => '/', // ajuste se for necessário
];
