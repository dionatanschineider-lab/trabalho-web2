<?php include __DIR__ . '/header.php'; ?>
<div class="jumbotron">
  <h1>Bem-vindo ao Sistema Web</h1>
  <p>Projeto modelo para o trabalho de WEB 2. Faça login ou registre-se para começar.</p>
</div>
<?php include __DIR__ . '/footer.php'; ?>
